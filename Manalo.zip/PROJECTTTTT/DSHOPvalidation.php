<?php
session_start();


/* Database Connection */
$con = mysqli_connect('localhost', 'root', '');
mysqli_select_db($con, 'registers_janine');
/* ------------------- */



$eusername = $_POST['username'];
$password = $_POST['password'];


$s = "select * from users where username = '$eusername' && password = '$password'";

$result = mysqli_query($con, $s);

$num = mysqli_num_rows($result);

if ($num == 1) {
	$_SESSION['username'] = $username;
	echo '<script>
		 window.location = "anotherpage.php"; 
		 alert("Log-in successfully.");
		 
 		 </script>';	

 		 // Directs to another new page after logging-in successfully. @Janine
}

else if ($num == 0) {
	echo '<script>
		 window.location = "DSHOP.php";
		 alert("Incorrect user/password.");
		 
 		 </script>';
}

else {
	header('location: DSHOP.php');	
}




?>


