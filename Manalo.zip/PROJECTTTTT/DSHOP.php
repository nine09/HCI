<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DelicaciesSHOP</title>
    <link rel="stylesheet" href="DSHOP.css">
</head>
<body>
    <form action = "DSHOPvalidation.php" method = "post"> <!-- Connects to the DSHOPvalidation.php file -->
    <div id="container">
        <main id="main">
            <div id="loginuicontainer">
                <div id="login-tab" class="active">Login</div><div id="register-tab"> Register </div> 
                <div id="logincontainer">
                    <div class="form-group">
                        <input type="text" class="form-control inputbox" id="login-username" placeholder="Email ID/Username" name = "username" required>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control inputbox" id="login-password" placeholder="Password" name = "password" required>
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btn btn-primary" value="Login">
                    </div>
                    <div class="textcenter signuptxt">Don't have an account?<a href="#" class="link registerlink">Sign up</a> </div>
                </div> 

            </form> <!-- END of Connection -->


            <form action = "DSHOPregistration.php" method = "post"> <!-- Connects to the DSHOPregistration.php file -->
                <div id="registercontainer" hidden>
                    <div class="form-group">
                        <input type="text" class="form-control inputbox" id="register-fname" placeholder="First Name" name = "fname" required>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control inputbox" id="register-lname" placeholder="Last Name" name = "lname" required>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control inputbox" id="register-email" placeholder="Email ID/Username" name = "username" required>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control inputbox" id="register-password" placeholder="Password" name = "password" required>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control inputbox" id="login-cnfmpassword" placeholder="Confirm Password" required>
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btn btn-primary" value="Register">
                    </div>
                    <div class="textcenter signuptxt">Already have an account?<a href="#" class="link loginlink">Log in</a> </div>
                </div> 
                </div>
            </div>
        </main>
    </div>
    </form> <!-- END of Connection -->


    <script src="DSHOP.js"></script>
</body>
</html>