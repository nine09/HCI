<?php
session_start();


/* Database Connection */
$con = mysqli_connect('localhost', 'root', '');
mysqli_select_db($con, 'registers_janine');
/* ------------------- */


$firstname = $_POST['fname'];
$lastname = $_POST['lname'];
$eusername = $_POST['username'];
$password = $_POST['password'];



$s = "select * from users where fname = '$firstname'";

$result = mysqli_query($con, $s);

$num = mysqli_num_rows($result);

if ($num == 1) {
	echo '<script>
		 window.location = "DSHOP.php";
		 alert("Username already taken.");
		 
 		 </script>';
}

else {
	$reg = "insert into users(fname, lname, username, password) values('$firstname', '$lastname', '$eusername', '$password')";
	mysqli_query($con, $reg);
	echo '<script>
		 window.location = "DSHOP.php";
		 alert("Registration successfully.");
		 
 		 </script>';
}




?>